.menu-section-blank i:before {
    font-family: FontAwesome;
    content: "\f069";
}
.menu-section-item-blank1:before {
    content: url(<?php echo ossn_site_url('components/Blank/images/blank1.png');?>) !important;
}
.menu-section-item-blank2:before {
    content: url(<?php echo ossn_site_url('components/Blank/images/blank2.png');?>) !important;
}
.menu-section-item-blank3:before {
    content: url(<?php echo ossn_site_url('components/Blank/images/blank3.png');?>) !important;
}
.menu-section-item-blank4:before {
    content: url(<?php echo ossn_site_url('components/Blank/images/blank4.png');?>) !important;
}