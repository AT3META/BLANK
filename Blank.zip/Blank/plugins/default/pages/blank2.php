<p></p>
<p>BLANK 2</p>
<p>
<iframe src="https://3ncircle.com" width="850" height="650" float="left" frameborder="0" allowfullscreen>
<p>Your browser does not support iframes.</p>
</iframe>
</p>
<p>
	<button class="btn btn-primary" align="center" onclick="NewTab()"> 
    FULLSCREEN 
    </button> 
    <script> 
        function NewTab() { 
            window.open("https://3ncircle.com", 
                    "", "width=888, height=666"); 
        } 
    </script>
</p>
